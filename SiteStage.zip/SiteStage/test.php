  <link rel="stylesheet" href="css.css">
<nav>
<ul>
<li><a href="#">Accueil</a></li>
<li><a href="#">Contact</a></li>
<!-- Début du menu déroulant -->
<li><a href="#">Menu1</a>
<ul>
<li><a href="#">Drop 1</a></li>
<li><a href="#">Drop 2</a></li>
<li><a href="#">Drop 3</a></li>
</ul>
</li>
<li><a href="#">Menu2</a></li>
</ul>
</nav>
